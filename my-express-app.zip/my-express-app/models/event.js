const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    rules: {
        type: String,
        required: true
    },
    type: {
        type: String,
        required: true
    },
    visible: {
        type: Boolean,
        default: true
    },
    registrationOpen: {
        type: Boolean,
        default: true
    },
    onstageEvents: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    offstageEvents: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    maxOnstageRegistrations: {
        type: Number,
        default: 4
    },
    maxOffstageRegistrations: {
        type: Number,
        default: 4
    }
});

module.exports = mongoose.models.Event || mongoose.model('Event', eventSchema);
