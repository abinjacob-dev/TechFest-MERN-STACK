const crypto = require('crypto');

const rolePermissions = {
  superadmin: {
    GET: [
      "/", "/events", "/events/:id/edit", "/event/:id/registrations", "/event/:id/registrations/search",
      "/event/:id/registrations/export/csv", "/event/:id/registrations/export/pdf", "/events/export/csv",
      "/events/export/pdf", "/custom-pages", "/custom-pages/new", "/custom-pages/:id/edit", "/users", "/users/new",
      "/users/:id/edit", "/users/search", "/registered-events", "/registered-events/onstage", "/registered-events/offstage",
      "/update-info", "/about", "/highlights", "/categories", "/schedule", "/rules", "/gallery", "/contact"
    ],
    POST: ["/events", "/custom-pages", "/users", "/update-info", "/register/:id"],
    PUT: ["/events/:id", "/events/:id/visibility", "/events/:id/registration", "/events/:id/max-registrations", "/custom-pages/:id", "/users/:id"],
    DELETE: ["/events/:id", "/custom-pages/:id", "/users/:id"]
  },
  admin: {
    GET: [
      "/", "/events", "/events/export/csv", "/events/export/pdf", "/event/:id/registrations", "/event/:id/registrations/export/csv",
      "/event/:id/registrations/export/pdf", "/users", "/users/:id/edit", "/users/search", "/registered-events", 
      "/registered-events/onstage", "/registered-events/offstage", "/update-info", "/about", "/highlights", "/categories",
      "/schedule", "/rules", "/gallery", "/contact"
    ],
    POST: ["/events", "/update-info", "/register/:id"],
    PUT: ["/users/:id"],
    DELETE: []
  },
  client: {
    GET: [
      "/", "/registered-events", "/registered-events/onstage", "/registered-events/offstage", "/update-info", "/event/:id/registrations",
      "/about", "/highlights", "/categories", "/schedule", "/rules", "/gallery", "/contact"
    ],
    POST: ["/update-info", "/register/:id"],
    PUT: [],
    DELETE: []
  },
  home: {
    GET: ["/", "/about", "/highlights", "/categories", "/schedule", "/rules", "/gallery", "/contact"],
    POST: [],
    PUT: [],
    DELETE: []
  }
};

// Middleware for role-based access control
function rbacMiddleware(role, method, route) {
  return function (req, res, next) {
    const roleHash = crypto.createHash('sha256').update(role).digest('hex');
    if (req.session.roleHash === roleHash) {
      const permissions = rolePermissions[role] && rolePermissions[role][method];
      if (permissions && (permissions.includes(route) || (role === 'superadmin' && route.startsWith('/')) || (role === 'admin' && (route.startsWith('/') || route.startsWith('/client') || route.startsWith('/admin'))) || (role === 'client' && (route.startsWith('/') || route.startsWith('/client'))))) {
        return next(); // Permission granted
      }
    }
    return res.status(403).render('access-denied', { message: "Access Denied" }); // No permission
  };
}

module.exports = rbacMiddleware;
