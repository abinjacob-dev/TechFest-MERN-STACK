const crypto = require('crypto');
const User = require('../models/user');

function authenticateSession(req, res, next) {
  if (req.session && req.session.userId) {
    return next(); // User is authenticated
  }
  return res.status(401).redirect('/signin');
}

async function setRoleInSession(req, res, next) {
  if (req.session.userId && !req.session.roleHash) {
    try {
      const user = await User.findById(req.session.userId);
      if (user) {
        const roleHash = crypto.createHash('sha256').update(user.role).digest('hex');
        req.session.roleHash = roleHash;
        res.setHeader('X-User-Role', roleHash);

        // Redirect based on role
        if (user.role === 'client') {
          return res.redirect('/client');
        } else if (user.role === 'admin') {
          return res.redirect('/admin');
        } else if (user.role === 'superadmin') {
          return res.redirect('/superadmin');
        }
      }
    } catch (err) {
      console.error('Error setting role in session:', err);
    }
  }
  next();
}

function isSuperAdmin(req, res, next) {
  if (req.session && req.session.roleHash) {
    const superAdminHash = crypto.createHash('sha256').update('superadmin').digest('hex');
    if (req.session.roleHash === superAdminHash) {
      return next(); // User is superadmin
    }
  }
  return res.status(403).render('access-denied', { message: "Access Denied" }); // Not superadmin
}

module.exports = { authenticateSession, setRoleInSession, isSuperAdmin };
