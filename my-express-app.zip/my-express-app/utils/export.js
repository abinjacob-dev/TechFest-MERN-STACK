const { Parser } = require('json2csv');
const PDFDocument = require('pdfkit');

function exportRegistrationsToCSV(registrations) {
    const fields = ['username', 'name', 'branch', 'semester', 'universityRegNo'];
    const opts = { fields };
    const parser = new Parser(opts);
    return parser.parse(registrations);
}

function exportRegistrationsToPDF(registrations) {
    return new Promise((resolve, reject) => {
        const doc = new PDFDocument();
        let buffers = [];
        doc.on('data', buffers.push.bind(buffers));
        doc.on('end', () => {
            const pdfData = Buffer.concat(buffers);
            resolve(pdfData);
        });

        doc.fontSize(12).text('Registrations', { align: 'center' });
        doc.moveDown();
        registrations.forEach(registration => {
            doc.text(`Username: ${registration.username}`);
            doc.text(`Name: ${registration.name}`);
            doc.text(`Branch: ${registration.branch}`);
            doc.text(`Semester: ${registration.semester}`);
            doc.text(`University Reg No: ${registration.universityRegNo}`);
            doc.moveDown();
        });

        doc.end();
    });
}

module.exports = {
    exportRegistrationsToCSV,
    exportRegistrationsToPDF
};
