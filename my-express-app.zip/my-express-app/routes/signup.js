const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');
const moment = require('moment-timezone');

router.get('/', (req, res) => {
    res.render('signup', { title: 'Sign Up', errorMessage: null });
});

router.post('/', async (req, res) => {
    try {
        const { username, password, phoneNumber, collegeMail, gender, universityRegNo, course, year, semester, name } = req.body;
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.render('signup', { title: 'Sign Up', errorMessage: 'Username has already signed up. Please sign in.' });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const signupDate = moment().tz('Asia/Kolkata').format('YYYY-MM-DD');
        const signupTime = moment().tz('Asia/Kolkata').format('hh:mm:ss A');
        const user = new User({
            name: name.toUpperCase(),
            username: username.toUpperCase(),
            password: hashedPassword,
            phoneNumber,
            collegeMail,
            gender,
            universityRegNo: universityRegNo.toUpperCase(),
            course,
            year,
            semester: `S${semester}`,
            role: 'user',
            signupDate,
            signupTime
        });
        await user.save();
        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.registeredEvents = user.registeredEvents;
        res.redirect('/');
    } catch (err) {
        console.error(err); // Log the error for debugging
        res.status(500).render('signup', { title: 'Sign Up', errorMessage: 'Server Error' });
    }
});

module.exports = router;
