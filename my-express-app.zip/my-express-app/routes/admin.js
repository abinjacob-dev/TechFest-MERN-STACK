const express = require('express');
const router = express.Router();
const rbacMiddleware = require('../middleware/rbac');
const Event = require('../models/event');
const User = require('../models/user');
const { authenticateSession, setRoleInSession } = require('../middleware/authenticate');


// Middleware to parse form data
router.use(express.urlencoded({ extended: true }));

// Protected routes
router.use(authenticateSession);
router.use(setRoleInSession);

router.get('/', rbacMiddleware('admin', 'GET', '/'), async (req, res) => {
  try {
    const eventsCount = await Event.countDocuments();
    const usersCount = await User.countDocuments();
    res.render('admin/index', { title: 'Admin', eventsCount, usersCount });
  } catch (err) {
    console.error('Error fetching counts:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/events', rbacMiddleware('admin', 'GET', '/events'), async (req, res) => {
  try {
    const { search = '', type = '' } = req.query;
    let query = {};
    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }
    if (type) {
      query.type = type;
    }
    const events = await Event.find(query);
    res.render('admin/events', { title: 'All Events', events, search, type });
  } catch (err) {
    console.error('Error fetching events:', err);
    res.status(500).send('Server Error');
  }
});

router.post('/events', rbacMiddleware('admin', 'POST', '/events'), async (req, res) => {
  try {
    const { name, type, description, rules } = req.body;
    const newEvent = new Event({ name, type, description, rules });
    await newEvent.save();
    res.redirect('/admin/events');
  } catch (err) {
    console.error('Error creating event:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/events/export/csv', rbacMiddleware('admin', 'GET', '/events/export/csv'), async (req, res) => {
  try {
    const events = await Event.find().populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });

    const fields = ['eventName', 'eventType', 'eventDescription', 'eventRules', 'username', 'name', 'branch', 'semester', 'universityRegNo'];
    const data = [];

    events.forEach(event => {
      const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
      clients.forEach(client => {
        data.push({
          eventName: event.name,
          eventType: event.type,
          eventDescription: event.description,
          eventRules: event.rules,
          username: client.username,
          name: client.name,
          branch: client.branch,
          semester: client.semester,
          universityRegNo: client.universityRegNo
        });
      });
    });

    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(data);

    res.header('Content-Type', 'text/csv');
    res.attachment('all_events_registrations.csv');
    res.send(csv);
  } catch (err) {
    console.error('Error exporting events to CSV:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/events/export/pdf', rbacMiddleware('admin', 'GET', '/events/export/pdf'), async (req, res) => {
  try {
    const events = await Event.find().populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });

    const doc = new PDFDocument();
    res.header('Content-Type', 'application/pdf');
    res.attachment('all_events_registrations.pdf');
    doc.pipe(res);

    doc.fontSize(20).text('All Events Registrations', { align: 'center' });
    doc.moveDown();

    events.forEach(event => {
      doc.fontSize(16).text(`Event Name: ${event.name}`);
      doc.fontSize(12).text(`Type: ${event.type}`);
      doc.text(`Description: ${event.description}`);
      doc.text(`Rules: ${event.rules}`);
      doc.moveDown();

      const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
      clients.forEach(client => {
        doc.text(`Username: ${client.username}`);
        doc.text(`Name: ${client.name}`);
        doc.text(`Branch: ${client.branch}`);
        doc.text(`Semester: ${client.semester}`);
        doc.text(`University Reg No: ${client.universityRegNo}`);
        doc.moveDown();
      });

      doc.addPage();
    });

    doc.end();
  } catch (err) {
    console.error('Error exporting events to PDF:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations', rbacMiddleware('admin', 'GET', '/event/:id/registrations'), async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });
    if (!event) {
      return res.status(404).send('Event not found');
    }
    const registrations = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
    res.render('admin/registrations', { title: 'Event Registrations', event, registrations });
  } catch (err) {
    console.error('Error fetching event registrations:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations/export/csv', rbacMiddleware('admin', 'GET', '/event/:id/registrations/export/csv'), async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });
    if (!event) {
      return res.status(404).send('Event not found');
    }
    const registrations = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
    const csv = exportRegistrationsToCSV(registrations);
    res.header('Content-Type', 'text/csv');
    res.attachment(`registrations_${event.name}.csv`);
    res.send(csv);
  } catch (err) {
    console.error('Error exporting event registrations to CSV:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations/export/pdf', rbacMiddleware('admin', 'GET', '/event/:id/registrations/export/pdf'), async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });
    if (!event) {
      return res.status(404).send('Event not found');
    }
    const registrations = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
    const pdf = await exportRegistrationsToPDF(registrations);
    res.header('Content-Type', 'application/pdf');
    res.attachment(`registrations_${event.name}.pdf`);
    res.send(pdf);
  } catch (err) {
    console.error('Error exporting event registrations to PDF:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/users', rbacMiddleware('admin', 'GET', '/users'), async (req, res) => {
  try {
    const users = await User.find({});
    res.render('admin/users', { title: 'All Users', users });
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/users/:id/edit', rbacMiddleware('admin', 'GET', '/users/:id/edit'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    res.render('admin/edit-user', { title: 'Edit User', user });
  } catch (err) {
    console.error('Error fetching user:', err);
    res.status(500).send('Server Error');
  }
});

router.put('/users/:id', rbacMiddleware('admin', 'PUT', '/users/:id'), async (req, res) => {
  try {
    const { name, username, email, phoneNumber, universityRegNo, year, semester, collegeMail, gender, course, branch, specialization } = req.body;
    const updatedUser = {
      name: name.toUpperCase(),
      username: username.toUpperCase(),
      email,
      phoneNumber,
      universityRegNo: universityRegNo.toUpperCase(),
      year,
      semester: `S${semester}`,
      collegeMail,
      gender,
      course,
      branch,
      specialization
    };
    await User.findByIdAndUpdate(req.params.id, updatedUser);
    res.redirect('/admin/users');
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).send('Server Error');
  }
});

router.get('/users/search', rbacMiddleware('admin', 'GET', '/users/search'), async (req, res) => {
  try {
    const query = req.query.query || '';
    const role = req.query.role || '';
    let searchCriteria = {
      $or: [
        { username: { $regex: query, $options: 'i' } },
        { name: { $regex: query, $options: 'i' } },
        { email: { $regex: query, $options: 'i' } },
        { phoneNumber: { $regex: query, $options: 'i' } },
        { universityRegNo: { $regex: query, $options: 'i' } }
      ]
    };
    if (role) {
      searchCriteria.role = role;
    }
    const users = await User.find(searchCriteria);
    res.json({ users });
  } catch (err) {
    console.error('Error searching users:', err);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
