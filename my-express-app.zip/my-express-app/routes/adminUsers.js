const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const User = require('../models/user'); // Assuming you have a User model

const rolePermissions = {
  admin: {
    GET: ["/", "/:id/edit"],
    POST: [],
    PUT: ["/:id"],
    DELETE: []
  }
};

function rbacMiddleware(role, method, route) {
  return function (req, res, next) {
    const permissions = rolePermissions[role] && rolePermissions[role][method];
    if (permissions && permissions.includes(route)) {
      return next(); // Permission granted
    } else {
      return res.status(403).json({ message: "Access Denied" }); // No permission
    }
  };
}

function authenticateJWT(req, res, next) {
  const authHeader = req.header('Authorization');
  console.log("Authorization Header:", authHeader);

  const token = authHeader?.split(' ')[1]; // Expecting "Bearer <token>"

  if (!token) {
    console.log("Token missing. Request headers:", req.headers);
    return res.status(401).json({ message: "Access denied, token missing" });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.log("Invalid token", err);
      return res.status(403).json({ message: "Invalid token" });
    }
    req.user = user;
    next();
  });
}

// Protected routes
router.get('/', authenticateJWT, rbacMiddleware('admin', 'GET', '/'), async (req, res) => {
  try {
    const users = await User.find({});
    res.render('admin/users', { title: 'All Users', users });
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.get('/:id/edit', authenticateJWT, rbacMiddleware('admin', 'GET', '/:id/edit'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    res.render('admin/edit-user', { title: 'Edit User', user });
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.put('/:id', authenticateJWT, rbacMiddleware('admin', 'PUT', '/:id'), async (req, res) => {
  try {
    const { name, username, email, phoneNumber, universityRegNo, year, semester, collegeMail, gender, course, branch, specialization } = req.body;
    const updatedUser = {
      name: name.toUpperCase(),
      username: username.toUpperCase(),
      email,
      phoneNumber,
      universityRegNo: universityRegNo.toUpperCase(),
      year,
      semester: `S${semester}`,
      collegeMail,
      gender,
      course,
      branch,
      specialization
    };
    await User.findByIdAndUpdate(req.params.id, updatedUser);
    res.redirect('/admin/users');
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

module.exports = router;