const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.render('home/index', { title: 'Home' });
});

router.get('/about', (req, res) => {
    res.render('home/about', { title: 'About the Festival' });
});

router.get('/highlights', (req, res) => {
    res.render('home/highlights', { title: 'Key Highlights' });
});

router.get('/categories', (req, res) => {
    res.render('home/categories', { title: 'Event Categories' });
});

router.get('/schedule', (req, res) => {
    res.render('home/schedule', { title: 'Schedule' });
});

router.get('/rules', (req, res) => {
    res.render('home/rules', { title: 'Rules and Guidelines' });
});

router.get('/gallery', (req, res) => {
    res.render('home/gallery', { title: 'Gallery' });
});

router.get('/contact', (req, res) => {
    res.render('home/contact', { title: 'Contact Us' });
});

module.exports = router;