const express = require('express');
const router = express.Router();
const rbacMiddleware = require('../middleware/rbac');
const Event = require('../models/event');
const CustomPage = require('../models/customPage');
const User = require('../models/user');
const methodOverride = require('method-override');
const bcrypt = require('bcrypt');
const { Parser } = require('json2csv');
const PDFDocument = require('pdfkit');
const moment = require('moment-timezone');
const { authenticateSession, setRoleInSession } = require('../middleware/authenticate');


// Middleware to parse form data
router.use(express.urlencoded({ extended: true }));
router.use(methodOverride('_method'));

// Protected routes
router.use(authenticateSession);
router.use(setRoleInSession);

router.get('/', rbacMiddleware('superadmin', 'GET', '/'), async (req, res) => {
  try {
    const eventsCount = await Event.countDocuments();
    const usersCount = await User.countDocuments();
    const customPagesCount = await CustomPage.countDocuments();
    res.render('superadmin/index', { 
      title: 'Superadmin', 
      eventsCount, 
      usersCount, 
      customPagesCount 
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/events', rbacMiddleware('superadmin', 'GET', '/events'), async (req, res) => {
  try {
    const { search = '', type = '' } = req.query;
    let query = {};
    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }
    if (type) {
      query.type = type;
    }
    let events = await Event.find(query);
    events = events.sort(() => Math.random() - 0.5); // Shuffle events
    res.render('superadmin/events', { title: 'All Events', events, search, type });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.post('/events',  rbacMiddleware('superadmin', 'POST', '/events'), async (req, res) => {
  const { name, description, rules, type } = req.body;
  try {
    const newEvent = new Event({ name, description, rules, type });
    await newEvent.save();
    res.redirect('/superadmin/events');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/events/:id/edit',  rbacMiddleware('superadmin', 'GET', '/events/:id/edit'), async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    res.render('superadmin/edit-event', { title: 'Edit Event', event });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.put('/events/:id',  rbacMiddleware('superadmin', 'PUT', '/events/:id'), async (req, res) => {
  const { name, description, rules, type, registrationOpenTime, registrationCloseTime } = req.body;
  try {
    const updateData = { name, description, rules, type };
    if (registrationOpenTime) {
      updateData.registrationOpenTime = new Date(registrationOpenTime);
    }
    if (registrationCloseTime) {
      updateData.registrationCloseTime = new Date(registrationCloseTime);
    }
    await Event.findByIdAndUpdate(req.params.id, updateData);
    res.redirect('/superadmin/events');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
  
});

router.put('/events/:id/visibility',  rbacMiddleware('superadmin', 'PUT', '/events/:id/visibility'), async (req, res) => {
  const { visible } = req.body;
  try {
    await Event.findByIdAndUpdate(req.params.id, { visible });
    res.redirect('/superadmin/events');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.put('/events/:id/registration',  rbacMiddleware('superadmin', 'PUT', '/events/:id/registration'), async (req, res) => {
  const { registrationOpen } = req.body;
  try {
    await Event.findByIdAndUpdate(req.params.id, { registrationOpen });
    res.redirect('/superadmin/events');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.put('/events/:id/max-registrations',  rbacMiddleware('superadmin', 'PUT', '/events/:id/max-registrations'), async (req, res) => {
  const { maxOnstageRegistrations, maxOffstageRegistrations } = req.body;
  try {
    await Event.findByIdAndUpdate(req.params.id, { maxOnstageRegistrations, maxOffstageRegistrations });
    res.redirect('/superadmin/events');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.delete('/events/:id',  rbacMiddleware('superadmin', 'DELETE', '/events/:id'), async (req, res) => {
  try {
    await Event.findByIdAndDelete(req.params.id);
    res.redirect('/superadmin/events');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations',  rbacMiddleware('superadmin', 'GET', '/event/:id/registrations'), async (req, res) => {
  try {
    const eventId = req.params.id;
    const event = await Event.findById(eventId).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });
    res.render('superadmin/event-registrations', {
      title: 'Event Registrations',
      event
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations/search',  rbacMiddleware('superadmin', 'GET', '/event/:id/registrations/search'), async (req, res) => {
  try {
    const eventId = req.params.id;
    const { search = '', branch = '' } = req.query;
    const event = await Event.findById(eventId).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo',
      match: {
        $and: [
          {
            $or: [
              { username: { $regex: search, $options: 'i' } },
              { name: { $regex: search, $options: 'i' } },
              { branch: { $regex: search, $options: 'i' } },
              { semester: { $regex: search, $options: 'i' } },
              { universityRegNo: { $regex: search, $options: 'i' } }
            ]
          },
          branch ? { branch } : {}
        ]
      }
    });
    const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
    res.json({ clients });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations/export/csv',  rbacMiddleware('superadmin', 'GET', '/event/:id/registrations/export/csv'), async (req, res) => {
  try {
    const eventId = req.params.id;
    const event = await Event.findById(eventId).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });
    const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;

    const fields = ['eventName', 'eventType', 'eventDescription', 'eventRules', 'username', 'name', 'branch', 'semester', 'universityRegNo'];
    const data = clients.map(client => ({
      eventName: event.name,
      eventType: event.type,
      eventDescription: event.description,
      eventRules: event.rules,
      username: client.username,
      name: client.name,
      branch: client.branch,
      semester: client.semester,
      universityRegNo: client.universityRegNo
    }));
    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(data);

    res.header('Content-Type', 'text/csv');
    res.attachment(`${event.name}_registrations.csv`);
    res.send(csv);
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations/export/pdf',  rbacMiddleware('superadmin', 'GET', '/event/:id/registrations/export/pdf'), async (req, res) => {
  try {
    const eventId = req.params.id;
    const event = await Event.findById(eventId).populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });
    const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;

    const doc = new PDFDocument();
    res.header('Content-Type', 'application/pdf');
    res.attachment(`${event.name}_registrations.pdf`);
    doc.pipe(res);

    doc.fontSize(20).text(`Registrations for ${event.name}`, { align: 'center' });
    doc.moveDown();
    doc.fontSize(12);
    doc.text(`Event Name: ${event.name}`);
    doc.text(`Type: ${event.type}`);
    doc.text(`Description: ${event.description}`);
    doc.text(`Rules: ${event.rules}`);
    doc.moveDown();
    clients.forEach(client => {
      doc.text(`Username: ${client.username}`);
      doc.text(`Name: ${client.name}`);
      doc.text(`Branch: ${client.branch}`);
      doc.text(`Semester: ${client.semester}`);
      doc.text(`University Reg No: ${client.universityRegNo}`);
      doc.moveDown();
    });

    doc.end();
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/events/export/csv',  rbacMiddleware('superadmin', 'GET', '/events/export/csv'), async (req, res) => {
  try {
    const events = await Event.find().populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });

    const fields = ['eventName', 'eventType', 'eventDescription', 'eventRules', 'username', 'name', 'branch', 'semester', 'universityRegNo'];
    const data = [];

    events.forEach(event => {
      const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
      clients.forEach(client => {
        data.push({
          eventName: event.name,
          eventType: event.type,
          eventDescription: event.description,
          eventRules: event.rules,
          username: client.username,
          name: client.name,
          branch: client.branch,
          semester: client.semester,
          universityRegNo: client.universityRegNo
        });
      });
    });

    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(data);

    res.header('Content-Type', 'text/csv');
    res.attachment('all_events_registrations.csv');
    res.send(csv);
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/events/export/pdf',  rbacMiddleware('superadmin', 'GET', '/events/export/pdf'), async (req, res) => {
  try {
    const events = await Event.find().populate({
      path: 'onstageEvents offstageEvents',
      select: 'username name branch semester universityRegNo'
    });

    const doc = new PDFDocument();
    res.header('Content-Type', 'application/pdf');
    res.attachment('all_events_registrations.pdf');
    doc.pipe(res);

    doc.fontSize(20).text('All Events Registrations', { align: 'center' });
    doc.moveDown();

    events.forEach(event => {
      doc.fontSize(16).text(`Event Name: ${event.name}`);
      doc.fontSize(12).text(`Type: ${event.type}`);
      doc.text(`Description: ${event.description}`);
      doc.text(`Rules: ${event.rules}`);
      doc.moveDown();

      const clients = event.type === 'onstage' ? event.onstageEvents : event.offstageEvents;
      clients.forEach(client => {
        doc.text(`Username: ${client.username}`);
        doc.text(`Name: ${client.name}`);
        doc.text(`Branch: ${client.branch}`);
        doc.text(`Semester: ${client.semester}`);
        doc.text(`University Reg No: ${client.universityRegNo}`);
        doc.moveDown();
      });

      doc.addPage();
    });

    doc.end();
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/custom-pages',  rbacMiddleware('superadmin', 'GET', '/custom-pages'), async (req, res) => {
  try {
    const pages = await CustomPage.find({});
    res.render('superadmin/custom-pages', { title: 'Custom Pages', pages });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/custom-pages/new',  rbacMiddleware('superadmin', 'GET', '/custom-pages/new'), (req, res) => {
  res.render('superadmin/new-custom-page', { title: 'Create New Custom Page' });
});

router.post('/custom-pages',  rbacMiddleware('superadmin', 'POST', '/custom-pages'), async (req, res) => {
  const { title, content } = req.body;
  try {
    const newPage = new CustomPage({ title, content });
    await newPage.save();
    res.redirect('/superadmin/custom-pages');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/custom-pages/:id/edit',  rbacMiddleware('superadmin', 'GET', '/custom-pages/:id/edit'), async (req, res) => {
  try {
    const page = await CustomPage.findById(req.params.id);
    res.render('superadmin/edit-custom-page', { title: 'Edit Custom Page', page });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.put('/custom-pages/:id',  rbacMiddleware('superadmin', 'PUT', '/custom-pages/:id'), async (req, res) => {
  const { title, content } = req.body;
  try {
    await CustomPage.findByIdAndUpdate(req.params.id, { title, content });
    res.redirect('/superadmin/custom-pages');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.delete('/custom-pages/:id',  rbacMiddleware('superadmin', 'DELETE', '/custom-pages/:id'), async (req, res) => {
  try {
    await CustomPage.findByIdAndDelete(req.params.id);
    res.redirect('/superadmin/custom-pages');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/custom-pages/search',  rbacMiddleware('superadmin', 'GET', '/custom-pages/search'), async (req, res) => {
  try {
    const query = req.query.query || '';
    const pages = await CustomPage.find({ title: { $regex: query, $options: 'i' } });
    res.json({ pages });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/users',  rbacMiddleware('superadmin', 'GET', '/users'), async (req, res) => {
  try {
    const users = await User.find({});
    res.render('superadmin/users', { title: 'All Users', users });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/users/new',  rbacMiddleware('superadmin', 'GET', '/users/new'), (req, res) => {
  res.render('superadmin/new-user', { title: 'Create New User' });
});

router.post('/users',  rbacMiddleware('superadmin', 'POST', '/users'), async (req, res) => {
  const { username, email, role, phoneNumber, collegeMail, gender, universityRegNo, course, year, semester, name, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const signupDate = moment().tz('Asia/Kolkata').format('YYYY-MM-DD');
    const signupTime = moment().tz('Asia/Kolkata').format('hh:mm:ss A');
    const newUser = new User({
      name: name.toUpperCase(),
      username: username.toUpperCase(),
      email,
      password: hashedPassword,
      phoneNumber,
      collegeMail,
      gender,
      universityRegNo: universityRegNo.toUpperCase(),
      course,
      year,
      semester: `S${semester}`,
      role,
      signupDate,
      signupTime
    });
    await newUser.save();
    res.redirect('/superadmin/users');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/users/:id/edit',  rbacMiddleware('superadmin', 'GET', '/users/:id/edit'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    res.render('superadmin/edit-user', { title: 'Edit User', user });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.put('/users/:id',  rbacMiddleware('superadmin', 'PUT', '/users/:id'), async (req, res) => {
  try {
    const { name, username, email, phoneNumber, universityRegNo, year, semester, collegeMail, gender, course, branch, specialization, role, password } = req.body;
    const updatedUser = {
      name: name.toUpperCase(),
      username: username.toUpperCase(),
      email,
      phoneNumber,
      universityRegNo: universityRegNo.toUpperCase(),
      year,
      semester: `S${semester}`,
      collegeMail,
      gender,
      course,
      branch,
      specialization,
      role
    };
    if (password) {
      updatedUser.password = await bcrypt.hash(password, 10);
    }
    await User.findByIdAndUpdate(req.params.id, updatedUser);
    res.redirect('/superadmin/users');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});

router.delete('/users/:id',  rbacMiddleware('superadmin', 'DELETE', '/users/:id'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (user.role === 'superadmin') {
      return res.status(403).send('Cannot delete superadmin');
    }
    await User.findByIdAndDelete(req.params.id);
    res.redirect('/superadmin/users');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/users/search',  rbacMiddleware('superadmin', 'GET', '/users/search'), async (req, res) => {
  try {
    const query = req.query.query || '';
    const role = req.query.role || '';
    let searchCriteria = {
      $or: [
        { username: { $regex: query, $options: 'i' } },
        { name: { $regex: query, $options: 'i' } },
        { email: { $regex: query, $options: 'i' } },
        { phoneNumber: { $regex: query, $options: 'i' } },
        { universityRegNo: { $regex: query, $options: 'i' } }
      ]
    };
    if (role) {
      searchCriteria.role = role;
    }
    const users = await User.find(searchCriteria);
    res.json({ users });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/pages', (req, res) => {
  // Logic to fetch and render all pages
  res.render('superadmin/pages', { title: 'All Pages' });
});

module.exports = router;
