const express = require('express');
const router = express.Router();
const rbacMiddleware = require('../middleware/rbac');
const Event = require('../models/event');
const User = require('../models/user');
const { authenticateSession, isSuperAdmin, setRoleInSession } = require('../middleware/authenticate');


// Middleware to parse form data
router.use(express.urlencoded({ extended: true }));

// Protected routes
router.use(authenticateSession);
router.use(setRoleInSession);

router.get('/', rbacMiddleware('client', 'GET', '/'), async (req, res) => {
  try {
    const searchQuery = req.query.search || '';
    const filterType = req.query.type || '';
    
    let query = { visible: true }; // Only show visible events
    if (searchQuery) {
      query.name = { $regex: searchQuery, $options: 'i' };
    }
    if (filterType) {
      query.type = filterType;
    }

    let events = await Event.find(query);

    // Shuffle events
    events = events.sort(() => Math.random() - 0.5);

    // Fetch the user from the database to get the latest registered events
    let user = null;
    if (req.session.userId) {
      user = await User.findById(req.session.userId).populate('registeredEvents');
    }

    res.render('client/index', {
      title: 'Client Page',
      searchQuery,
      filterType,
      events,
      user // Pass the user object to the view
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/registered-events', rbacMiddleware('client', 'GET', '/registered-events'), async (req, res) => {
  try {
    const user = await User.findById(req.session.userId).populate('registeredEvents');
    res.render('client/registered-events', {
      title: 'Registered Events',
      events: user.registeredEvents
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/registered-events/onstage', rbacMiddleware('client', 'GET', '/registered-events/onstage'), async (req, res) => {
  try {
    const user = await User.findById(req.session.userId).populate({
      path: 'registeredEvents',
      match: { type: 'onstage' }
    });
    res.render('client/registered-onstage-events', {
      title: 'Registered Onstage Events',
      events: user.registeredEvents
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/registered-events/offstage', rbacMiddleware('client', 'GET', '/registered-events/offstage'), async (req, res) => {
  try {
    const user = await User.findById(req.session.userId).populate({
      path: 'registeredEvents',
      match: { type: 'offstage' }
    });
    res.render('client/registered-offstage-events', {
      title: 'Registered Offstage Events',
      events: user.registeredEvents
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/update-info', rbacMiddleware('client', 'GET', '/update-info'), async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);
    res.render('client/update-info', {
      title: 'Update Personal Information',
      user
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.post('/update-info', rbacMiddleware('client', 'POST', '/update-info'), async (req, res) => {
  try {
    const { name, phoneNumber, collegeMail, gender, universityRegNo, course, branch, specialization, year, semester } = req.body;
    const userId = req.session.userId;

    await User.findByIdAndUpdate(userId, {
      name,
      phoneNumber,
      collegeMail,
      gender,
      universityRegNo,
      course,
      branch,
      specialization,
      year,
      semester
    });

    res.redirect('/client/update-info');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.post('/register/:id', rbacMiddleware('client', 'POST', '/register/:id'), async (req, res) => {
  try {
    const eventId = req.params.id;
    const userId = req.session.userId; // Assuming user is authenticated and req.session.userId is available

    const event = await Event.findById(eventId);
    const user = await User.findById(userId);

    // Check if the user has already registered for the maximum number of events
    const onstageCount = user.registeredEvents.filter(event => event.type === 'onstage').length;
    const offstageCount = user.registeredEvents.filter(event => event.type === 'offstage').length;

    if ((event.type === 'onstage' && onstageCount >= event.maxOnstageRegistrations) || 
        (event.type === 'offstage' && offstageCount >= event.maxOffstageRegistrations)) {
      return res.status(400).send('You have reached the maximum number of registrations for this type of event.');
    }

    if (event.type === 'onstage') {
      await Event.findByIdAndUpdate(eventId, { $addToSet: { onstageEvents: userId } });
    } else if (event.type === 'offstage') {
      await Event.findByIdAndUpdate(eventId, { $addToSet: { offstageEvents: userId } });
    }

    // Add the event to the user's registered events
    const updatedUser = await User.findByIdAndUpdate(userId, { $addToSet: { registeredEvents: eventId } }, { new: true });

    // Update the user object in the session
    req.session.user = updatedUser;

    res.status(200).send('Registered successfully');
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.post('/reregister/:eventId/:userId', isSuperAdmin, async (req, res) => {
  try {
    const { eventId, userId } = req.params;

    console.log(`Attempting to allow re-registration for user ${userId} to event ${eventId}`);

    const event = await Event.findById(eventId);
    const user = await User.findById(userId);

    if (!event) {
      const msg = `Event with ID ${eventId} not found`;
      console.error(msg);
      throw new Error(msg);
    }

    if (!user) {
      const msg = `User with ID ${userId} not found`;
      console.error(msg);
      throw new Error(msg);
    }

    // Remove the event from the user's registered events
    await User.findByIdAndUpdate(userId, { $pull: { registeredEvents: eventId } });

    // Remove the user from the event's registered users
    if (event.type === 'onstage') {
      await Event.findByIdAndUpdate(eventId, { $pull: { onstageEvents: userId } });
    } else if (event.type === 'offstage') {
      await Event.findByIdAndUpdate(eventId, { $pull: { offstageEvents: userId } });
    }

    console.log(`Successfully allowed re-registration for user ${userId} to event ${eventId}`);
    res.status(200).send('User can now re-register for the event');
  } catch (err) {
    console.error('Error during re-registration:', err); // Log the error
    res.status(500).send('Server Error');
  }
});

router.get('/event/:id/registrations', rbacMiddleware('client', 'GET', '/event/:id/registrations'), async (req, res) => {
  try {
    const eventId = req.params.id;
    const event = await Event.findById(eventId).populate({
      path: 'onstageEvents offstageEvents',
      populate: {
        path: 'onstageEvents offstageEvents',
        select: 'username name branch semester universityRegNo'
      }
    });
    res.render('superadmin/event-registrations', {
      title: 'Event Registrations',
      event
    });
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).send('Server Error');
  }
});

module.exports = router;