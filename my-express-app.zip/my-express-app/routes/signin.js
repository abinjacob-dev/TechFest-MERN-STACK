const express = require("express");
const router = express.Router();
const User = require("../models/user");
const bcrypt = require("bcrypt");

router.get("/", (req, res) => {
  res.render("signin", { title: "Sign In", errorMessage: null });
});

router.post("/", async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username }).populate("registeredEvents");
    if (!user) {
      return res.render("signin", {
        title: "Sign In",
        errorMessage: "Invalid username or password",
      });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.render("signin", {
        title: "Sign In",
        errorMessage: "Invalid username or password",
      });
    }
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.registeredEvents = user.registeredEvents;
    res.redirect("/");
  } catch (err) {
    console.error(err); // Log the error for debugging
    res
      .status(500)
      .render("signin", { title: "Sign In", errorMessage: "Server Error" });
  }
});

module.exports = router;
